﻿using Intern1.Utility;
using OpenQA.Selenium;
using System;
using TechTalk.SpecFlow;

namespace Intern1.StepDefinitions
{
    [Binding]
    public class PropertyreteLoginSteps
    {
        [Given(@"I navigate to the url propertyrete\.com")]
        public void GivenINavigateToTheUrlPropertyrete_Com()
        {
           Hooks.driver.Navigate().GoToUrl("https://www.propertyrete.com");
        }
        
        [Given(@"I click on Login")]
        public void GivenIClickOnLogin()
        {
            Hooks.driver.FindElement(By.XPath("//*[@id=\"ct-js-wrapper\"]/div[2]/div/div/div[2]/div/div[1]/a")).Click();
        }
        
        [Given(@"I input your email")]
        public void GivenIInputYourEmail()
        {
            Hooks.driver.FindElement(By.XPath("//*[@id=\"ct-js-wrapper\"]/section/header/div/div/div/form/div/div/div[2]/input")).Click();
            Hooks.driver.FindElement(By.XPath("//*[@id=\"ct-js-wrapper\"]/section/header/div/div/div/form/div/div/div[2]/input")).SendKeys("goziegbe@gmail.com");
        }
        
        [Given(@"I input your password")]
        public void GivenIInputYourPassword()
        {
            Hooks.driver.FindElement(By.XPath("//*[@id=\"ct-js-wrapper\"]/section/header/div/div/div/form/div/div/div[3]/input")).Click();
            Hooks.driver.FindElement(By.XPath("//*[@id=\"ct-js-wrapper\"]/section/header/div/div/div/form/div/div/div[3]/input")).SendKeys("goziegbe@gmail.com");
        }
        
        [Given(@"I input your wrong password")]
        public void GivenIInputYourWrongPassword()
        {
            Hooks.driver.FindElement(By.XPath("//*[@id=\"ct-js-wrapper\"]/section/header/div/div/div/form/div/div/div[3]/input")).Click();
            Hooks.driver.FindElement(By.XPath("//*[@id=\"ct-js-wrapper\"]/section/header/div/div/div/form/div/div/div[3]/input")).SendKeys("goziegbe@gmail.com");
        }
        
        [When(@"I press Login")]
        public void WhenIPressLogin()
        {
            Hooks.driver.FindElement(By.XPath("//*[@id=\"ct-js-wrapper\"]/section/header/div/div/div/form/div/div/div[5]/button")).Click();
           
        }
        
        [Then(@"I should be taken to my propertyrete profile page")]
        public void ThenIShouldBeTakenToMyPropertyreteProfilePage()
        {
            Hooks.driver.Close();
        }
        
        [Then(@"I should be shown an error message")]
        public void ThenIShouldBeShownAnErrorMessage()
        {
            
        }
    }
}
